#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include <string.h>


int main(int argc,char *argv[])
{
    //encodeInfo encInfo;

    if(argc >2)
    {
        int option =  check_operation_type(argv);
        if(option == e_encode)
        {
            EncodeInfo encInfo;
            printf("INFO: user entered the encode operation\n");
            if(read_and_validate_encode_args(argv,&encInfo) == e_success)
            {
                printf("INFO: validation success\n");
                if(do_encoding(&encInfo) == e_success)
                {
                    printf("INFO: ## Encoding Done Successfully ##\n");
                }
                else
                {
                    printf("INFO: ## Do_encoding Failure ##\n");
                    return e_failure;
                }
            }
            else
            {
                printf("INFO: Validation failure\n");
            }            
        }
        else if(option == e_decode)
        {
            DecodeInfo decInfo;
            printf("INFO: user entered the decode operation\n");
            if(read_and_validate_decode_args(argv,&decInfo) == e_success)
            {
                printf("INFO: Validation success\n");
                if(do_decoding(&decInfo) == e_success)
                {
                    printf("INFO: ## Decode Done Successfully ##\n");
                }
                else
                {
                    printf("INFO: ## do_decoding failure ##");
                    return e_failure;
                }
            }
        }
        else
        {
            printf("INFO: Validation failure\n");
        }
    }
    else
    {
        printf("./sb_steg: Encoding: ./sb_steg -e <.bmp file> <.txt file> [output file]\n");
        printf("./sb_steg: Decoding: ./sb_steg -d <.bmp file> <output file>\n");
    }
}
OperationType check_operation_type(char *argv[])
{
    if((strcmp(argv[1],"-e") == 0))
        return e_encode;
    if((strcmp(argv[1],"-d") == 0))
        return e_decode;
    else
        return e_unsupported;
}



