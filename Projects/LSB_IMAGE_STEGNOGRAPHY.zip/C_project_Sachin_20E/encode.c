#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"

/* Function Definitions */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if((strcmp((strstr(argv[2],".")),".bmp")) == 0)
    {
        encInfo -> src_image_fname = argv[2];
      //printf(".bmp file present\n");
    }
    else
    {
        printf("./sb_steg: Encoding: ./sb_steg -e <.bmp file> <.txt file> [output file]\n");
        return e_failure;
    }
 
    if((strstr(argv[3],".")) != NULL)
    {
        encInfo -> secret_fname = argv[3];
        strcpy(encInfo -> extn_secret_file,strstr(encInfo -> secret_fname,"."));
    }
    else
    {
        printf("./sb_steg: Encoding: ./sb_steg -e <.bmp file> <.txt file> [output file]\n");
        return e_failure;
    }
 
    if(argv[4] != NULL)
    {
        if((strcmp((strstr(argv[4],".")),".bmp")) == 0)
        {
            encInfo -> stego_image_fname = argv[4];
        }
        else
        {
            return e_failure;
        }
    }
    else
    {
        encInfo -> stego_image_fname = "stego.bmp";
        printf("INFO: Output File Not Mentioned Creating %s as default\n",encInfo -> stego_image_fname);
    }
    return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    printf("INFO: Opening Required Files\n");
    if(open_files(encInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: Files Not Opened\n");
        return e_failure;
    }
    //check capcity
    printf("INFO: ## Encoding Procedure Started ##\n");
    printf("INFO: Checking for %s Size\n",encInfo -> secret_fname);
    fseek(encInfo -> fptr_secret,0,SEEK_END);
    if(ftell(encInfo -> fptr_secret) > 0)
    {
        printf("INFO : DONE Not Empty\n");
    }
    else
    {
        printf("INFO: File Empty\n");
    }
    printf("INFO: Checking For %s Capacity To  Handle %s\n",encInfo->src_image_fname,encInfo->secret_fname);
    if(check_capacity(encInfo) == e_success)
    {
        printf("INFO: Done Found Ok\n");
    }
    else
    {
        printf("INFO: Not Done\n");
        return e_failure;
    }
    printf("INFO: Copying Image Header\n");
    //copy bmp header
    if(copy_bmp_header(encInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("copy_bmp_header not succcessfull\n");
        return e_failure;
    }
    //encode magic string
    printf("INFO: Encoding Magic String Signature\n");
    if(encode_magic_string(MAGIC_STRING, encInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: Encode magic_string not done\n");
        return e_failure;
    }
    //encode secret file extn size
    printf("INFO: Encoding %s file extension size\n",encInfo -> secret_fname);
    if(encode_secret_file_extn_size(strlen(encInfo -> extn_secret_file),encInfo -> fptr_src_image,encInfo -> fptr_stego_image)==e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("Secret File Extension Size Failed\n");
        return e_failure;
    }
    //encode file extn
    printf("INFO: Encoding %s File Extension\n",encInfo -> secret_fname);

    if(encode_secret_file_extn(encInfo -> extn_secret_file,encInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("Secret File Extension Failed\n");
        return e_failure;
    }
    //file size
    printf("INFO: Encoding %s File Size\n",encInfo -> secret_fname);
    if(encode_secret_file_size(encInfo -> size_secret_file,encInfo)==e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("Secret File size Failed\n");
        return e_failure;
    }
    //file data
    printf("INFO: Encoding %s File Data\n",encInfo -> secret_fname);
    if(encode_secret_file_data(encInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: Secret File Data Failed\n");
        return e_failure;
    }
    //
    printf("INFO: Copying Left Over Data\n");
    if(copy_remaining_img_data(encInfo -> fptr_src_image,encInfo ->fptr_stego_image) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("Copying Data Failure\n");
        return e_failure;
    }
    return e_success;
}
//
Status open_files(EncodeInfo *encInfo)
{   
    //
    encInfo -> fptr_src_image = fopen(encInfo -> src_image_fname, "r");
    if((encInfo -> fptr_src_image) != NULL)   //source image
    {
        printf("INFO: source file open success\n");
    }
    else
    {
        printf("INFO: source file not opened\n");
        return e_failure;
    }
    //
    encInfo -> fptr_secret = fopen(encInfo -> secret_fname, "r");
    if((encInfo -> fptr_secret ) != NULL)
    { 
       printf("INFO: secret file open successfully\n");
    }
    else  
    {
       printf("secret file not open successfully\n");
        return e_failure;
    }
    //
    encInfo -> fptr_stego_image = fopen(encInfo -> stego_image_fname, "w");
    if((encInfo -> fptr_stego_image) != NULL)
    {
        printf("INFO: stego file open successfully\n");
    }
    else
    {
        printf("stego file not open successfully\n");
        return e_failure;
    }
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo ->image_capacity = get_image_size_for_bmp(encInfo -> fptr_src_image);
    encInfo ->size_secret_file = get_file_size(encInfo -> fptr_secret);
    rewind(encInfo->fptr_src_image);
    if(encInfo ->image_capacity >((strlen(MAGIC_STRING) + 4 + 4 + 4 + encInfo -> size_secret_file)*8))
        return e_success;
    else
        return e_failure;
}

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width,height;
    fseek(fptr_image,18,SEEK_SET);

    fread(&width,sizeof(int),1,fptr_image);
  //  printf("width = %u\n",width);

    fread(&height, sizeof(int),1,fptr_image);
   // printf("height = %u\n",height);

    return width *height * 3;
}

long get_file_size(FILE *fptr)
{
    fseek(fptr,0L,SEEK_END);
    return ftell(fptr);
}
//
Status copy_bmp_header(EncodeInfo *encInfo)
{
    char header[54];
    fread(header,54,1,encInfo -> fptr_src_image);
    fwrite(header,54,1,encInfo -> fptr_stego_image);
    return e_success;
}
//
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    encode_data_to_image(MAGIC_STRING, strlen(magic_string),encInfo -> fptr_src_image, encInfo -> fptr_stego_image);
    return e_success;
}
//
void encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    for(int i=0; i<size;i++)
    {
        char buffer[8];
        fread(buffer ,1,8,fptr_src_image);
        for(int j=0;j<8;j++)
        {
            buffer[j] = ((buffer[j] & (~1)) | ((unsigned)(data[i] & 1<<j)>>j));
        }
        fwrite(buffer,1,8,fptr_stego_image);
    }        
}
//

Status encode_secret_file_extn_size(int size,FILE *fptr_src_image,FILE *fptr_stego_image)
{
    char buffer[32];
    fread(buffer ,32,1,fptr_src_image);
    for(int j=0;j<32;j++)
    {
        buffer[j] = ((buffer[j] & (~1)) | ((unsigned)(size & 1<<j)>>j));
    }
    fwrite(buffer,32,1,fptr_stego_image);
    return e_success;
}        

Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn,strlen(file_extn),encInfo -> fptr_src_image,encInfo->fptr_stego_image);
    return e_success;
}


Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer ,32,1,encInfo -> fptr_src_image);
    for(int j=0;j<32;j++)
    {
        buffer[j] = ((buffer[j] & (~1)) | ((unsigned)(file_size & 1<<j)>>j));
    }
    fwrite(buffer,32,1,encInfo -> fptr_stego_image);
    return e_success;
}        
//
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_secret,0L,SEEK_SET);
    char buffer[encInfo->size_secret_file];
    fread(buffer,encInfo->size_secret_file ,1,encInfo->fptr_secret);
    encode_data_to_image(buffer,strlen(buffer),encInfo -> fptr_src_image,encInfo ->fptr_stego_image);
   // printf("copy is = %ld\n",ftell(encInfo -> fptr_stego_image));
    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while((fread(&ch,1,1,fptr_src))> 0)
    {
        fwrite(&ch,1,1,fptr_dest);
    }
    return e_success;
}

