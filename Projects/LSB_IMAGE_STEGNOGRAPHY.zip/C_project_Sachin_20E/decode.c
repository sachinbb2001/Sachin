#include <stdio.h>
#include "common.h"
#include "decode.h"
#include "types.h"
#include <string.h>

int extn_size;
int data_size;
char *optional;
char extn[20];
char extn_1[24];
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if((strcmp((strstr(argv[2],".")),".bmp")) == 0)
    {
        decInfo -> src_image_fname = argv[2];
       // printf(".bmp file present\n");
    }
    else
    {
        printf("./sb_steg: Decoding: ./sb_steg -d <.bmp file> [output file]\n");
        return e_failure;
    }
    if(argv[3] != NULL)
    {
      //  printf("file is present\n");
        if(strstr(argv[3],".")!= NULL)
        {
         //   printf("file is present\n");
            char *buffer = argv[3];
        }
        else
        {
            return e_failure;
        }
    }
    else
    {
       optional = "output";
    }
    return e_success;
}
  
Status do_decoding(DecodeInfo *decInfo)
{
    printf("INFO: ## Decoding Procedure Started ##\n");
    printf("INFO: Opening Required Files\n");
    if(open_file(decInfo) == e_success)
    {
      //  printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: Files Not Opened\n");
        return e_failure;
    }
    if(decode_header_file(decInfo) == e_success)
    {
      //  printf("header files skipped\n");
    }
    else
    {
        return e_failure;
    }
    printf("INFO: Decoding Magic String Signature\n");
    if(decode_magic_string(decInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: magic string decoded succe\n");
        return e_failure;
    }
    printf("INFO: Decoding Output File Extension Size\n");
    if(decode_secret_file_extn_size(decInfo) == e_success)
    {
        printf("INFO: Done\n"); 
    }
    else
    {
        printf("secret file extn size successful\n");
        return e_failure;
    }
    
    printf("INFO: Decoding Output File Extension\n");
    if(decode_secret_file_extn(extn_size,decInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: Decoding file extn complete\n");
        return e_failure;
    }
    
    printf("INFO: Decoding Output File Data Size\n");
    if(decode_secret_file_size(decInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: decode secret file sie complete\n");
        return e_failure;
    }
    
    printf("INFO: Decoding Output File Data\n");
    if(decode_secret_file_data(data_size,decInfo) == e_success)
    {
        printf("INFO: Done\n");
    }
    else
    {
        printf("INFO: secret file data complete\n");
        return e_failure;
    }
   
    return e_success;
}

Status open_file(DecodeInfo *decInfo)
{
   decInfo -> fptr_src_image  = fopen(decInfo ->src_image_fname,"r");
   if((decInfo -> fptr_src_image) != NULL)
   {
     //  printf("sourece file open\n");
   }
   else
   {
       printf("INFO: Source file not opened\n");
       return e_failure;
   }
   return e_success;
}

Status decode_header_file(DecodeInfo *decInfo) 
{
    fseek(decInfo -> fptr_src_image,54,SEEK_SET);
    return e_success;
}


Status decode_magic_string(DecodeInfo *decInfo)
{
    char buffer[8];
    char magic_string[4];
    for(int i=0; i<2; i++)
    {
        fread(buffer,1,8,decInfo -> fptr_src_image);
        magic_string[i] = decode_byte_to_lsb(buffer);
    }
    magic_string[3]='\0';
    if(strcmp(magic_string,MAGIC_STRING)==0)
    {
       // printf("INFO: magic string mtched\n");
    }
    else
    {
        printf("INFO: Magic String Not mtched\n");
    }

    return e_success;
}

Status decode_byte_to_lsb(char buffer[])
{
    char ch=0;
    for(int i=0; i<8;i++)
    {
        ch =(((buffer[i] & 1) << i) | ch);
    }
    return ch;
}

Status decode_size_to_lsb(char buffer[])
{
    int size=0;
    for(int i=0; i<32;i++)
    {
        size = (((buffer[i] & 1) <<i) | size);
    }
    return size;
}

Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char buffer[32];
    fread(buffer,1,32,decInfo -> fptr_src_image);
    extn_size = decode_size_to_lsb(buffer);

return e_success;
}

Status decode_secret_file_extn(int extn_size,DecodeInfo *decInfo)
{
    char buffer[8];
    char file_extn[extn_size+1];
    for(int i=0; i<extn_size; i++)
    {
        fread(buffer,1,8,decInfo -> fptr_src_image);

        file_extn[i] = decode_byte_to_lsb(buffer);
    }
    file_extn[extn_size] ='\0';
    strcpy(extn,file_extn);
    char scc[20];
    strcpy(scc,optional);
    strcat(scc,extn);
    strcpy(extn_1,scc);
    decInfo -> secret_fname = extn_1;
    decInfo -> fptr_secret = fopen(decInfo -> secret_fname , "w");

    return e_success;
}

Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char buffer[32];
    fread(buffer,1,32,decInfo -> fptr_src_image);
    data_size = decode_size_to_lsb(buffer);
   // printf("%d",data_size);
    return e_success;
}

Status decode_secret_file_data(int data_size,DecodeInfo *decInfo)
{
    char buffer[8];
    char file_data[data_size+1];
    int i=0;
    for( i=0; i<data_size; i++)
    {
        fread(buffer,1,8,decInfo -> fptr_src_image);

        file_data[i] = decode_byte_to_lsb(buffer);
        
    }
    file_data[i] ='\0';
   // printf("%s",file_data);
    fwrite(file_data,1,data_size,decInfo -> fptr_secret);
    fclose(decInfo -> fptr_secret);
    
    return e_success;
}

