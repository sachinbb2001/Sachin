#include "main.h"

unsigned char read_external_eeprom(unsigned char address) {
    unsigned char data;

    i2c_start();
    i2c_write(0xA0);
    i2c_write(address);
    i2c_rep_start();
    i2c_write(0xA1);
    data = i2c_read();
    i2c_stop();

    return data;
}

void view_log() {
    //logic of view log
    if (C_flag == 1 || event_change==0) 
    {
        CLEAR_DISP_SCREEN;
        clcd_print("NO LOGS....     ", LINE1(0));
        for (int j = 5000; j--;)
                for (int i = 100; i--;);
        main_f = 2;
        return;
    } 
    else
    {
        key = read_switches(LEVEL_CHANGE);
        if (key != ALL_RELEASED) 
        {
            backup_key = key;
            delay1++;
            if (delay1 > 300) 
            {
                delay1 = 0;
                if (backup_key == MK_SW12)
                {
                    CLEAR_DISP_SCREEN;
                    __delay_us(500);
                    main_f = 2;
                    return;
                }
            }
        } 
        else if (delay1 > 0 && delay1 < 300)
        {
            delay1 = 0;
            if (backup_key == MK_SW11)
            {   
                if(count>0)
                    count--;
            }
            else if(backup_key == MK_SW12)
            {
                if(count<9)
                    count++;             
            }
        }
        else 
            delay1=0;
    }
    if (count < event_change) {
        read[0] = count + 48;
        read[1] = ' ';
        read[2] = read_external_eeprom(count * 10 + 0);
        read[3] = read_external_eeprom(count * 10 + 1);
        read[4] = ':';
        read[5] = read_external_eeprom(count * 10 + 2);
        read[6] = read_external_eeprom(count * 10 + 3);
        read[7] = ':';
        read[8] = read_external_eeprom(count * 10 + 4);
        read[9] = read_external_eeprom(count * 10 + 5);
        read[10] = ' ';
        read[11] = read_external_eeprom(count * 10 + 6);
        read[12] = read_external_eeprom(count * 10 + 7);
        read[13] = ' ';
        read[14] = read_external_eeprom(count * 10 + 8);
        read[15] = read_external_eeprom(count * 10 + 9);
        read[16] = '\0';
    }
    clcd_print(read, LINE2(0));
}
