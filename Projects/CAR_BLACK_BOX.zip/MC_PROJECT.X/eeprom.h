#ifndef EEPROM_H
#define EEPROM_H



#define CNTL_ADDR		0x07

void write_external_eeprom(unsigned char address, unsigned char data); 
unsigned char read_external_eeprom(unsigned char address);


#endif