#include "main.h"

void change_pass() {
    key = read_switches(LEVEL_CHANGE);
    if (i == 0) {
        clcd_print("Enter Password", LINE1(0));
    }
    if (i < 4) {
        if (wait1++ <= 200) {
            clcd_putch('_', LINE2(i));
        } else if (wait1++ <= 400) {
            clcd_putch(' ', LINE2(i));
        }
        else {
            wait1 = 0;
        }
        if (key == MK_SW11) {
            pass1[i] = 0;
            clcd_putch('*', LINE2(i));
            i++;
        } else if (key == MK_SW12) {
            pass1[i] = 1;
            clcd_putch('*', LINE2(i));
            i++;
        }

        if (i == 4) {
            clcd_print("Re Enter Password", LINE1(0));
        }
    }
    else if (j < 4) {
        if (wait2++ <= 200) {
            clcd_putch('_', LINE2(j));
        }
        else if (wait2++ <= 400) {
            clcd_putch(' ', LINE2(j));
        }
        else {
            wait2 = 0;
        }

        if (key == MK_SW11) {
            pass2[j] = 0;
            clcd_putch('*', LINE2(j));
            j++;
        }
        else if (key == MK_SW12) {
            pass2[j] = 1;
            clcd_putch('*', LINE2(j));
            j++;
        }
    } else {
        if (pass1[i] != pass2[j]) {
            clcd_print("Wrong Password  ", LINE1(0));
            for (int k = 5000; k--;);
            clcd_print("                ", LINE1(0));
            i = 0, j = 0;
            main_f = 2;
            return;
        }
        i++;
        j++;
        for (int m = 0; m < 4; m++)
            write_external_eeprom(200 + m, pass1[m]);
        clcd_print("Correct Password", LINE1(0));
        clcd_print("Changes  Success", LINE2(0));
        for (int k = 5000; k--;);
        clcd_print("                ", LINE1(0));
        i = 0, k = 0;
        main_f = 2;
        return;
    }
}