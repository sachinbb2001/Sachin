#include "main.h"

void __interrupt() isr(void) {
    static unsigned short count;
    if (TMR0IF) {
        TMR0 = TMR0 + 8;
        if (count++ == 20000) {
            count = 0;
            --sec;
        }
        TMR0IF = 0;
    }
}

void init_timer(void) {
    PEIE = 1;
    init_timer0();
    GIE = 1;
}

void init_timer0(void) {
    T08BIT = 1;
    T0CS = 0;
    TMR0ON = 1;
    PSA = 1;
    TMR0 = 6;
    TMR0IF = 0;
    TMR0IE = 1;
}


void password(char key) {
    key = read_switches(STATE_CHANGE);

    clcd_print("Enter Password", LINE1(0));
    if (wait++ <= 200) {
        clcd_putch('_', LINE2(i));
    } else if (wait++ <= 400) {
        clcd_putch(' ', LINE2(i));
    }
    else {
    wait = 0;
    }
    if (key == MK_SW11) {
        temp_pass[i] = 0;
        clcd_putch('*', LINE2(i));
        i++;
    } else if (key == MK_SW12) {
        temp_pass[i] = 1;
        clcd_putch('*', LINE2(i));
        i++;
    }
    if (i == 4) {
        for (int j = 0; j < 4; j++) {
            if (org_pass[j] != temp_pass[j]) {
                i = 0;
                break;
            }
        }
        if (i == 4) {
            CLEAR_DISP_SCREEN;
            clcd_print("SUCCESFULL", LINE1(0));
            for (int j = 5000; j--;)
                for (int i = 100; i--;);
            CLEAR_DISP_SCREEN;
            main_f = 2;
            return;
        } else if (i == 0) {
            flag1++;
            clcd_print("Attempt failed", LINE1(0));
            clcd_print("Attempt left ", LINE2(0));
            clcd_putch(3 - flag1 + '0', LINE2(13));
            for (int j = 5000; j--;)
                for (int i = 100; i--;);
            CLEAR_DISP_SCREEN;
        }
        if (flag1 == 3) {
            sec = 120;
            while (sec > 0) {
                clcd_print("You Are Blocked", LINE1(0));
                clcd_print("Wait For ", LINE2(0));
                clcd_putch((sec / 100) + 48, LINE2(10));
                clcd_putch(((sec / 10) % 10) + 48, LINE2(11));
                clcd_putch((sec % 10) + 48, LINE2(12));
            }
            CLEAR_DISP_SCREEN;
            
                main_f = 0;
                return;
        }
    }
}