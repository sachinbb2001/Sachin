#include"main.h"

void settime()
{   
    static char flag=1;
    if(t_flag)
    {
        seconds = (time[6]-48)*10+(time[7]-48);
        min = (time[3]-48)*10+(time[4]-48);
        hour = (time[0]-48)*10+(time[1]-48);
        t_flag = 0;
    }
    key = read_switches(LEVEL_CHANGE);
    if(key != ALL_RELEASED)
    {
        backup_key = key;
        delay3++;
        if(delay3 > 200)
        {
            delay3 = 0;
            if(backup_key  == MK_SW12)
            {
                write_ds1307(HOUR_ADDR,(hour/10)<<4 | (hour%10));
                write_ds1307(MIN_ADDR,min);
                write_ds1307(SEC_ADDR,seconds);
                
                clcd_print("successfully   ",LINE2(0));
                for(int k=3000; k--; )
                    for(int l=100;l--;);
                CLEAR_DISP_SCREEN;
                main_f = 2;
            }
            else if(backup_key  == MK_SW11)
            {
                CLEAR_DISP_SCREEN;
                main_f = 2;
            }
        }
    }
    else if(delay3 >0 && delay3 < 200)
    {
        delay3 = 0;
        if(backup_key  == MK_SW11)
        {
            if(flag == 1)
            {
                hour++;
                if(hour > 23)
                hour = 0;
            }
            else if(flag == 2)
            {
                min++;
                if(min > 59)
                min = 0;
            }
            else if(flag == 3)
            {
                seconds++;
                if(seconds > 59)
                seconds = 0;
            }
        }  
    }
    else if(backup_key  == MK_SW12)
    {
        if(flag == 1)
            flag = 2;
        else if(flag == 2)
            flag = 3;
        else if(flag == 3)
           flag = 1;
    }
    else
    {
        delay3 = 0;
    }
    
    if(wait1++ < 100) 
    {
        clcd_putch(hour/10+48, LINE2(0));
        clcd_putch(hour%10+48, LINE2(1));
        clcd_putch(':', LINE2(2));
        clcd_putch(min/10+48, LINE2(3));
        clcd_putch(min%10+48, LINE2(4));
        clcd_putch(':', LINE2(5));
        clcd_putch(seconds/10+48, LINE2(6));
        clcd_putch(seconds%10+48, LINE2(7));
    }
    else if(wait1 < 200)
    {
        if(flag == 1)
        {
            clcd_print("  ", LINE2(0));
        }
        else if(flag == 2)
        {
            clcd_print("  ", LINE2(3));
        }
        else if(flag == 3)
        {
            clcd_print("  ", LINE2(6));
        }
    } 
    else
        wait1 = 0;
}
   
           