#include "main.h"

void init_config(void)
{
    init_clcd();
	init_i2c();
    init_ds1307();
    init_adc();
    init_matrix_keypad();
    init_timer(); 
}

void main(void) {
    init_config();
    write_external_eeprom(0x50, 1);
    write_external_eeprom(0x51, 1);
    write_external_eeprom(0x52, 0);
    write_external_eeprom(0x53, 0);
   
	org_pass[0] = read_external_eeprom(0x50);
    org_pass[1] = read_external_eeprom(0x51);
    org_pass[2] = read_external_eeprom(0x52);
    org_pass[3] = read_external_eeprom(0x53);
    
    while (1)
    {   
        if(main_f == DASHBOARD)
        {
            clcd_print("TIME", LINE1(0));
            clcd_print("EV", LINE1(11));
            clcd_print("SP", LINE1(14));
            dashboard(); 
        } 
        else if(main_f == PASSWORD)
        {   
            password(key);
        }
        else if(main_f == MENU)
        {
            menu();
        }
        else if(main_f == MENU_ENTER)
        {
            if(menu_f == VIEWLOG)
            {
                view_log();
            }          
            else if(menu_f == DOWNLOADLOG)
            {
                download_log();
            }           
            else if(menu_f == CLEARLOG)
            {
                clear_log();
            }    
            else if(menu_f == SETTIME)
            {
                settime();
            }
            else if(menu_f == CHANGEPASS)
            {
                change_pass();
            } 
        }
    }
    return;
}
