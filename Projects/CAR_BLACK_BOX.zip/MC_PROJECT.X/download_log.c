#include"main.h"

void download_log() {
    init_uart();
    key = read_switches(LEVEL_CHANGE);

    if (C_flag == 1 || event_change == 0) {
        clcd_print("No LOGS>>>>     ", LINE1(0));
        puts("NO LOGS\n\r");
        for (int j = 5000; j--;)
            for (int i = 100; i--;);
        main_f = 2;
        event_change = 0;
        return;
    } else {
        clcd_print("downloading logs", LINE1(0));
        for (int j = 5000; j--;)
            for (int i = 100; i--;);
        if (key != ALL_RELEASED) {
            backup_key = key;
            delay2++;
            if (delay2 > 300) {
                delay2 = 0;
                if (backup_key == MK_SW12) {
                    CLEAR_DISP_SCREEN;
                    main_f = 2;
                    return;
                }
            }
        }
        for (int i = 0; i < event_change; i++) {
            read[0] = count + 48;
            read[1] = ' ';
            read[2] = read_external_eeprom(i * 10 + 0);
            read[3] = read_external_eeprom(i * 10 + 1);
            read[4] = ':';
            read[5] = read_external_eeprom(i * 10 + 2);
            read[6] = read_external_eeprom(i * 10 + 3);
            read[7] = ':';
            read[8] = read_external_eeprom(i * 10 + 4);
            read[9] = read_external_eeprom(i * 10 + 5);
            read[10] = ' ';
            read[11] = read_external_eeprom(i * 10 + 6);
            read[12] = read_external_eeprom(i * 10 + 7);
            read[13] = ' ';
            read[14] = read_external_eeprom(i * 10 + 8);
            read[15] = read_external_eeprom(i * 10 + 9);
            read[16] = '\0';
        }
        puts("#TIME     EV  SP\n\r");
        puts(read);
        puts("\n\r");
    }

}
