#include"main.h"

void menu() {
    char log[5][17] = {"view log       ", "download log   ", "clear log      ", "set time       ", "change password "};
    char key = read_switches(LEVEL_CHANGE);
    if (k == 0) 
    {
        clcd_putch('*', LINE1(0));
        clcd_putch(' ', LINE2(0));
    } 
    else 
    {
        clcd_putch(' ', LINE1(0));
        clcd_putch('*', LINE2(0));
    }

    clcd_print(log[first], LINE1(1));
    clcd_print(log[first + 1], LINE2(1));
    if (key != ALL_RELEASED)
    {
        backup_key = key;
        delay++;
        if (delay > 300) 
        {
            delay = 0;
            if (backup_key == MK_SW11) 
            {
                CLEAR_DISP_SCREEN;
                main_f = 3;
                menu_f = k + first;
                if (menu_f == 0)
                {
                    clcd_print("#logs           ", LINE1(0));
                    __delay_us(1500);
                    CLEAR_DISP_SCREEN;
                    clcd_print("# TIME     EV SP",LINE1(0));
                } 
                else if(menu_f == 3)
                {
                    clcd_print("HH:MM:SS        ",LINE1(0));
                }
            } 
            else if (backup_key == MK_SW12)
            {
                CLEAR_DISP_SCREEN;
                main_f = 0;
            }
        }
    } 
    else if (delay > 0 && delay < 300)
    {
        delay = 0;
        if (backup_key == MK_SW11) 
        {
            if (k == 1)
                k = 0;
            else if (first > 0)
                first--;
        } 
        else if (backup_key == MK_SW12) 
        {
            if (k == 0)
                k = 1;
            else if (first < 3)
                first++;
        }
    } 
    else
    {
        delay = 0;
    }
}

