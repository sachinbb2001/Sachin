#include "main.h"

void clear_log() {
    C_flag = 1;
    clcd_print("logs cleared    ", LINE1(0));
    for (int k = 3000; k--;)
        for (int l = 100; l--;);
    CLEAR_DISP_SCREEN;
    main_f=2;
    return;
}
