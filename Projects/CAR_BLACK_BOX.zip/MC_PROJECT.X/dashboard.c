#include "main.h"

void dashboard(void) {
    get_time();
    display_time();
    adc_reg_val = read_adc(CHANNEL4);
    check_speed(adc_reg_val);
    check_matrix_keypad();
}

void display_time(void) {
    clcd_print(time, LINE2(0));
}

void get_time(void) {

    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);

    if (clock_reg[0] & 0x40) {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    } else {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}

void check_matrix_keypad(void) {
    unsigned char key;
    static unsigned int i = 0;
    unsigned int flag;
    key = read_switches(STATE_CHANGE);

    if (key == MK_SW1) {
        event_change++;
        if (i == 8) {
            i = 1;
        }
        i++;
        if (i >= 7) {
            i = 7;
        }
        store_event(i);
    } else if (key == MK_SW2) {
        event_change++;
        if (i > 1 && i != 8) {
            i--;
            if (i < 1) {
                i = 1;
            }
        }
        store_event(i);
    } else if (key == MK_SW3) {
        event_change++;
        i = 8;
        store_event(i);
    } else if (key == MK_SW11) {
        CLEAR_DISP_SCREEN;
        main_f = 1;
        return;
    }
    clcd_print(arr[i], LINE2(11));
}

void check_speed(unsigned short adc_reg_val) {
    ch = adc_reg_val / 10.33;
    clcd_putch((ch / 10) + 48, LINE2(14));
    clcd_putch((ch % 10) + 48, LINE2(15));
}
