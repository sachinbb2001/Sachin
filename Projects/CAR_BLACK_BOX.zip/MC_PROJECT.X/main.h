#ifndef MAIN
#define MAIN

#include <xc.h>
#include "clcd.h"
#include "ds1307.h"
#include "i2c.h"
#include "matrix_keypad.h"
#include "adc.h"
#include "eeprom.h"
#include "uart.h"

#define DASHBOARD               0
#define PASSWORD                1
#define MENU                    2
#define MENU_ENTER              3
#define VIEWLOG                 0
#define DOWNLOADLOG             1
#define CLEARLOG                2
#define SETTIME                 3
#define CHANGEPASS              4
#define RX_PIN					TRISC7
#define TX_PIN					TRISC6

unsigned int main_f = 0,menu_f = 0;

unsigned char clock_reg[3];
unsigned char time[9];
unsigned char arr[9][3] = {"ON","GR","GN","G1","G2","G3","G4","G5"," C"};
unsigned char org_pass[4]={'1','1','1','1'};
unsigned char temp_pass[4];
unsigned char read[16];
unsigned char pass1[4], pass2[4];
unsigned char store[11]= {};

static unsigned char key,backup_key;
unsigned char first = 0;

unsigned int flag1 = 0,t_flag = 1,count=0,C_flag=0;
unsigned int wait = 0,wait1 = 0, wait2 = 0;
unsigned int delay = 0,delay1=0,delay2 = 0,delay3=0;
unsigned int hour, min, seconds;
unsigned int lap = 0;
unsigned int event_change=0;

unsigned short ch;
unsigned short adc_reg_val;

static unsigned char sec;
static unsigned int i = 0,j=0,k=0;

void dashboard();               
void store_event();
void password(char key);
void menu();
void view_log();
void download_log();
void clear_log();
void settime();
void change_pass();
void get_time(void);
void display_time(void);

void init_timer0(void);
void init_timer(void);

void init_uart(void);
void putch(unsigned char byte);
int puts(const char *s);
unsigned char getch(void);
unsigned char getch_with_timeout(unsigned short max_time);
unsigned char getche(void);

#endif