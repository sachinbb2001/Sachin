#include "main.h"

void write_external_eeprom(unsigned char address, unsigned char data)
{
	i2c_start();
	i2c_write(0xA0);
	i2c_write(address);
	i2c_write(data);
	i2c_stop();
}

void store_event(unsigned int i) {
    
    store[0] = time[0];
    store[1] = time[1];
    store[2] = time[3];
    store[3] = time[4];
    store[4] = time[6];
    store[5] = time[7];
    store[6] = arr[i][0];
    store[7] = arr[i][1];
    store[8] = (ch / 10) + 48;
    store[9] = (ch % 10) + 48;

    for (i = 0; i < 10; i++) 
    {
        write_external_eeprom(lap * 10 + i, store[i]);
    }
    lap++;
    if (lap == 10) {
        lap = 0;
    }
}
