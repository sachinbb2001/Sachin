#include "main.h"
int read_and_validate(int argc,char *argv[],FILE_T **list)
{
	for(int i = 1; i< argc; i++)
	{
       if((strstr(argv[i], ".txt")) != NULL)
       {
		   printf("INFO : %s Contain .txt\n",argv[i]);
	   }
	   else
	   {
		   printf("ERROR : %s Not Content .txt\n",argv[i]);
		   return FAILURE;
	   }

	   FILE *fptr = fopen(argv[i],"r");
	   fseek(fptr,-0L,SEEK_END);
	   if(ftell(fptr)<=0)
	   {
		   fseek(fptr,0L,SEEK_SET);
		   printf("ERROR : %s is Empty\n",argv[i]);
		   continue;
	   }
	   else
	   {
		  printf("INFO : %s is Not Empty\n",argv[i]);
		  if((find_Duplicate(argv[i],list)) == SUCCESS)
		  {
			  if((Create_List(argv[i],list)) == SUCCESS)
			  {
				  printf("INFO : List Created successfull\n");
			  }
			  else
			  {
				  printf("ERROR : List Not Created\n");
				  return FAILURE;
			  } 
		  }
		  else
		  {
			  printf("INFO :%s is Duplicte\n",argv[i]);
		  }
  	  
	   }
	} 
	return SUCCESS;
}
//Find Duplicate
int find_Duplicate(char *name,FILE_T **head)
{
	if(*head == NULL)
	{
		return SUCCESS;
	}
	FILE_T *temp = *head;
	while(temp !=NULL)
	{
		if(strcmp(name,temp->file_name)==0)
		{
			return FAILURE;
		}
		else
		temp = temp -> link;
	}
	return SUCCESS;
}

//creating list
int Create_List(char *argv,FILE_T **head)
{

	FILE_T *new = malloc(sizeof(FILE_T));
	if(new == NULL)
		return FAILURE;
	new -> link = NULL;

	strcpy(new -> file_name,argv);
//	printf("%s\n",new->file_name);

	if(*head == NULL)
	{
		*head = new;
		return SUCCESS;
	}
	FILE_T *temp = *head;
	while(temp -> link != NULL)
	{
		temp = temp -> link;
	}
	temp -> link = new;
	return SUCCESS;	
}
