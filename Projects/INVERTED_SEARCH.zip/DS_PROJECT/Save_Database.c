#include "main.h"
int Save_Database(main_node *head[],char file[20])
{
	if(strstr(file,".txt") != NULL) 
	{
		FILE *fptr = fopen(file,"w");
		if(fptr == NULL)
			return FAILURE;
		for(int i=0; i<28; i++)
		{
			if(head[i] != NULL)
			{
				main_node *temp = head[i];
				while(temp != NULL)
				{
					sub_node *temp1 = temp -> slink;
					fprintf(fptr,"#%d;%s;%d",i,temp -> word,temp->file_count);
					while(temp1 != NULL)
					{	
						fprintf(fptr,";%s;%d",temp1->file_name,temp1->word_count);
						temp1 = temp1 -> link;
					}
					fprintf(fptr,";#");
					fprintf(fptr,"\n");
					temp = temp -> mlink;
				}
			}
		}
	}
	else
	{
		printf("file is not .txt\n");
		return FAILURE;
	}
	return SUCCESS;
}

