#include "main.h"
int Create_Database(main_node *head[],FILE_T *list)
{
	FILE_T *temp = list;
	while(temp !=NULL)
	{
		int index;
		FILE *fptr = fopen(temp->file_name,"r");
		char word[20];
		while((fscanf(fptr,"%s",word)) != EOF)
		{ 
			if((word[0] >= 'a' && word[0] <= 'z')  || (word[0] >= 'A' && word[0] <= 'Z'))
			{
				index = tolower(word[0])- 97;	
			}
			else if(word[0] >= '0' && word[0] <= '9')
			{
				index = 26;
			}
			else
			{
				index = 27;
			}

			if(head[index] == NULL)
			{
				main_node *mnew = malloc(sizeof(main_node));
				sub_node *snew = malloc(sizeof(sub_node));
				snew -> link =NULL;
				mnew -> mlink =NULL;
				strcpy(mnew -> word, word);
				//	printf("%s",mnew ->word);
				mnew -> file_count = 1;
				mnew -> slink = snew;

				strcpy(snew ->file_name,temp->file_name);
				//	printf("%s",snew ->file_name);	
				snew -> word_count = 1;
				head[index] =  mnew;
			}
			else
			{
				main_node *temp1 = head[index];
				main_node *prev1 = NULL;
				int  flag_1 = 0;
				while(temp1 != NULL)
				{
					if((strcmp(temp1 -> word,word)) == 0)
					{
						sub_node *temp2 = temp1 ->slink;
						sub_node *prev2 = NULL;
						int flag_2=0;
						while(temp2 != NULL)
						{
							if((strcmp(temp2->file_name,temp ->file_name))==0)
							{
								flag_2 = 1;
								(temp2 -> word_count)++;
								break;
							}
							prev2 = temp2;
							temp2 = temp2 -> link;
						}

						if(flag_2 != 1)
						{ 
							sub_node *snew = malloc(sizeof(sub_node));
							snew -> link = NULL;
							snew -> word_count = 1;
							strcpy(snew -> file_name, temp-> file_name);
							(temp1->file_count)++;
							prev2 -> link = snew;
						}
						flag_1=1;
						break;
					}
					prev1 = temp1;
					temp1 = temp1 -> mlink;	
				}
				if(flag_1 != 1)
				{
					main_node *mnew = malloc(sizeof(main_node));
					sub_node *snew = malloc(sizeof(sub_node));
					mnew->mlink=NULL;

					strcpy(mnew -> word, word);
					mnew -> file_count = 1;
					mnew -> slink = snew;
					prev1->mlink=mnew;

					strcpy(snew ->file_name,temp->file_name);
					snew -> word_count = 1;
					snew-> link = NULL;
				}
			}
		}
		temp = temp -> link;
	}
	return SUCCESS;
}

