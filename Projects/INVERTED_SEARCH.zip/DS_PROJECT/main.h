#ifndef FILE_H
#define FILE_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#define SUCCESS 1
#define FAILURE 0

typedef struct file
{
	char file_name[50];
    struct file *link;
}FILE_T;

typedef struct mainnode
{
	int file_count;
	char word[10];
    struct subnode *slink;
	struct mainnode *mlink;
}main_node;

typedef struct subnode
{
	int word_count;
	char file_name[50];
	struct subnode *link;
}sub_node;


int read_and_validate(int argc,char *argv[],FILE_T **head);
int find_Duplicate(char *argv,FILE_T **head);
int Create_List(char *argv,FILE_T **head);
int Create_Database(main_node *head[],FILE_T *link);
int Display_Database(main_node *head[]);
int Search_Database(main_node *head[],char *word);
int Save_Database(main_node *head[],char file[]);
int Update_Database(main_node *head[],char file[],FILE_T **list);
int delete_file(char *str,FILE_T **head);
void print_list(FILE_T *head);
#endif
