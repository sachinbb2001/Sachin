#include "main.h"
int Update_Database(main_node *head[],char file[20],FILE_T **list)
{
	if((strstr(file,".txt")) != NULL) 
	{
		printf("INFO : %s Contain .txt\n",file);
	}
	else
	{
		printf("ERROR : %s Not Content .txt\n",file);
    	return FAILURE; 
	}

	FILE *fptr = fopen(file,"r");
	fseek(fptr,-0L,SEEK_END);
	if(ftell(fptr)<=0)
	{
		printf("ERROR : %s is Empty\n",file);
		return FAILURE;
	}
	else
	{
		rewind(fptr);
		printf("INFO : %s is Not Empty\n",file);
		FILE *fptr = fopen(file,"r");
		char str[100];
		while((fscanf(fptr,"%s",str)) !=EOF)
		{
			if(str[0] == '#')
			{
				int index = atoi(strtok(&str[1],";"));
				main_node *mnew = malloc(sizeof(main_node));
				sub_node *snew = malloc(sizeof(sub_node));
				snew -> link =NULL;
				mnew -> mlink =NULL;
				strcpy(mnew -> word,strtok(NULL,";"));
				mnew -> file_count = (atoi(strtok(NULL,";")));
				strcpy(snew -> file_name,strtok(NULL,";"));
				snew -> word_count = (atoi(strtok(NULL,";")));
				delete_file((snew ->file_name),list);
				mnew -> slink = snew;
				sub_node *temp = snew;
				for(int i=1; i<mnew -> file_count; i++)
				{
					sub_node *stemp = malloc(sizeof(sub_node));
					strcpy(stemp ->file_name,strtok(NULL,";"));
					stemp -> word_count = (atoi(strtok(NULL,";")));
					delete_file((snew ->file_name),list);
					temp->link = stemp;
					temp = temp->link; 
				}
				if(head[index] == NULL)
				{
					head[index] =  mnew;
				}
				else
				{	
					main_node *temp = head[index];
					while(temp -> mlink != NULL)
					{
						temp = temp -> mlink;
					}
					temp -> mlink = mnew;
				}
			}
			else
			{
				return FAILURE;
			}
		}	
	}
	return SUCCESS;
}

int delete_file(char *str,FILE_T **head)
{
	if(*head == NULL)
		return FAILURE;
	FILE_T *temp = *head;
	FILE_T *prev = temp;
	if(strcmp(temp -> file_name,str) == 0)
	{
		*head = temp ->link;;
		free(temp);
		return 0;
	}
	while(temp != NULL)
	{
		if(strcmp(temp -> file_name,str) == 0)
		{
			prev ->link = temp ->link;
			free(temp);
			return 0;
		}
		prev =temp;
		temp = temp ->link;
	}
	return 0;
}
