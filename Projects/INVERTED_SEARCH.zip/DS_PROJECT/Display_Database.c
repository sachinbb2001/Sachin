#include "main.h"

 //Dispaly_Database
int Display_Database(main_node *head[])
{
	printf("INDEX	WORD	 F_COUNT     F_NAME        W_COUNT     F_NAME          W_COUNT\n");
	for(int i=0; i<28; i++)
	{
		if(head[i] != NULL)
		{
			main_node *temp = head[i];
			while(temp != NULL)
			{
		    	sub_node *temp1 = temp -> slink;
				printf("%d	%s	 %d",i,temp -> word,temp->file_count);
				while(temp1 != NULL)
				{	
					printf("           %s	   %d",temp1->file_name,temp1->word_count);
					temp1 = temp1 -> link;
				}
				temp = temp -> mlink;
				printf("\n");
			}
			printf("\n");
		}
	}
	return SUCCESS;
}
