#include "main.h"

//Search database
int Search_Database(main_node *head[],char *word)
{
	int index;
	if((word[0] >= 'a' && word[0] <= 'z')  || (word[0] >= 'A' && word[0] <= 'Z'))
	{
		index = tolower(word[0])- 97;	
	}
	else if(word[0] >= '0' && word[0] <= '9')
	{
		index = 26;
	}
	else
	{
		index = 27;
	}


	if(head[index] == NULL)
	{
		printf("%s word NOT FOUND\n",word);
	}
	main_node *temp = head[index];
	while(temp != NULL)
	{
		if((strcmp(temp -> word,word)) ==0)
		{ 
			printf("word %s present in %d file/s\n",word ,temp->file_count);
		//	printf("index -> [%d] word -> [%s] Filecount -> [%d]\n",index,temp -> word,temp->file_count);
			sub_node *temp1 = temp ->slink;
			while(temp1!=NULL)
			{
					printf("In File : %s %d\n",temp1->file_name,temp1->word_count);
					temp1 = temp1 -> link;
			}
			printf("\n");

		}
		temp =temp->mlink;
	}
	return SUCCESS;
}
