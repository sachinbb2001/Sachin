#include "main.h"

int main(int argc,char *argv[])
{
	if(argc> 1)
	{
  		FILE_T *link = NULL;
        main_node *head[28]={0};
		char word[10];

		if((read_and_validate(argc,argv,&link)) == SUCCESS)
		{
		    printf("----------------------------------\n");
			printf("INFO : Validation DONE\n");
			printf("----------------------------------\n");
			print_list(link);
			char ch = 'y';
			int option;
			int flag=0;
			while((ch == 'y') || (ch == 'Y'))
			{
				printf("Enter the choice : \n");
				printf("----------------------------------\n");
				printf("1. Create DATABASE\n2. Display Database\n3. Update DATABASE \n4. Search Database\n5. Save DATABASE\n6. Exit\nEnter your choice : \n");
				printf("----------------------------------\n");
				scanf("%d", &option);
				switch (option)
				{
					case 1:
						printf("----------------------------------\n");
						if (Create_Database(head,link) == SUCCESS) 
						{
							flag=1;
							printf("Database Created\n");
							printf("----------------------------------\n");
						}
						else
						{
							printf("Database Not Created\n");
						}
						break;

					case 2:
						printf("----------------------------------\n");
						if (Display_Database(head) == SUCCESS)
						{
							printf("INFO :DATBASE Displayed Successfuly\n");
							printf("----------------------------------\n");
						}
						else
						{
							printf("INFO : DATABASE Not Dispalyed\n");
						}
						break;

					case 3:
						char U_file[50];
						if(flag==0)
						{
							printf("Enter the file you want to update = ");
							scanf("%s",U_file);
							printf("----------------------------------\n");
						
							if (Update_Database(head,U_file,&link) == SUCCESS)
							{
								printf("INFO : Update Database Successfull\n");
								printf("----------------------------------\n");
							}
							else
							{
								printf("INFO : Update Database Not Successfull\n");
							}
							break;
						}
						else
						{
							printf("ERROR : -----------\n");
							break;
						}
					case 4:
						printf("Enter the word you want to search = ");
						scanf("%s",word);

						printf("----------------------------------\n");
						if (Search_Database(head,word) == SUCCESS)
						{
							printf("INFO : Search Is Succefull\n");
							printf("----------------------------------\n");
						}
						else
						{
							printf("INFO : Search Word Successfull\n");
						}

						break;

					case 5:
						printf("Enter the file you want to save in : "); 
						char save_file[20];
						scanf("%s",save_file);
						printf("----------------------------------\n");
						if (Save_Database(head,save_file)==SUCCESS)
						{
							printf("INFO : Save Database Successful\n");
							printf("----------------------------------\n");
						}
						else
						{
							printf("INFO : Save Database Not Successfull\n");
						}
						break;
					case 6:
						return 0;
					default: printf("Enter proper choice !!\n");
							 break;
				}
				getchar();
				printf("Do you Want to Continue?\n");
				printf("Enter Y/y -> continue or N/n -> Discontinue\n");
				scanf("%c",&ch);
			}

		}

		else
		{
			printf("ERROR : Validation FAILED\n");
		}

	}

	else
	{
		printf("ERROR : Pass Files To Command Line \n");
	}
	return 0;
}

void print_list(FILE_T *head)
{
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
		while (head)		
		{
			printf("%s -> ", head -> file_name);
			head = head -> link;
		}

	printf("NULL\n");
	}
}
