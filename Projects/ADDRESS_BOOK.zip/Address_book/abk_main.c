#include<stdio.h>
#include<stdlib.h>

struct student
{
       char name[30];
       char mob[15];
       char email[20];
       int id;
};

//add_student details
void add_student(FILE *fp, struct student *p)
{
	printf("Enter student id : ");
	scanf("%d", &(p->id));
	printf("Enter student name : ");
	scanf(" %[^\n]", p->name);
	printf("Enter student mob : ");
	scanf(" %[^\n]", p->mob);
	printf("Enter student email id : ");
	scanf(" %[^\n]", p->email);

	fprintf(fp, "%d %s %s %s\n", p->id, p->name, p->mob, p->email);
	
	printf("-------------------------------\n");
	printf("Student added succesfully\n");
	printf("-------------------------------\n");
	fclose(fp);
}

//display student details
void disp_student(FILE *fp, struct student *p)
{
	rewind(fp);
	while (fscanf(fp, "%d %s %s %s", &(p->id), p->name, p->mob, p->email))
	{
		if (feof(fp))
			break;
		printf("%d %s %s %s\n", p->id, p->name, p->mob, p->email);
	}
	fclose(fp);
}


//delete student details
void del_student(FILE *fp, struct student *p)
{
	int id;
	printf("Enter the student id to be deleted : ");
	scanf("%d", &id);
	FILE *fp1 = fopen("temp.txt", "a+");
	while (fscanf(fp, "%d %s %s %s", &(p->id), p->name, p->mob, p->email))
	{
		if (id != p->id)
		{
			fprintf(fp1, "%d %s %s %s\n", p->id, p->name, p->mob, p->email);
		}
		if (feof(fp))
			break;
	}
	remove("data.txt");
	rename("temp.txt", "data.txt");
	rewind(fp1);
	printf("------------------------------------\n");
	printf("Student details sucessfully deleted\n");
	printf("------------------------------------\n");
	fclose(fp);
	fclose(fp1);
}


int main()
{

	printf("::W:E:L:C:O:M:E::T:O::A:D:D:R:E:S:S::B:O:O:K::\n");
	struct student s;
	int i = 1;
	while (i == 1)
	{
		printf("-------------------------------\n");
		printf("1.Add student details\n2.Display student details\n3.Delete student details\n4.Exit\n");
		printf("-------------------------------\n");
		int opt;
		printf("Enter an option from the above : ");	
		scanf("%d", &opt);
		printf("\n-------------------------------\n");
		FILE *fp = fopen("data.txt", "a+");
		switch (opt)
		{
			case 1: add_student(fp, &s);
					break;

			case 2: disp_student(fp, &s);
					break;

			case 3: del_student(fp, &s);
					break;

			case 4: printf("::T:h:a:n:k::y:o:u::\n");
					exit(0);
					break;

			default: printf("Please enter a valid option!!!\n");
					 break;
		}
		printf("Do you want to continue\nIf yes press 1 or press 0\n");
		scanf("%d", &i);
		if (i == 0)
		{
			printf("Thank you have a nice day\n");
		}
		else if (i != 1)
		{
			printf("Please enter valid input!!!\n");
label:
			printf("Select a valid option again\n");
			scanf("%d", &i);
			if (i != 1)
			{
				goto label;
			}
		}

	}

	return 0;
}

