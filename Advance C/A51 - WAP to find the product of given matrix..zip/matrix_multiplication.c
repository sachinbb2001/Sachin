#include <stdio.h>
#include <stdlib.h>
/*
Name: Sachin Belavi
Date: 25/10/2023
Title:WAP to find the product of given matrix.
Sample Input:
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :
1      2      3
1      2      3
1      2      3
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :

1      1     1
2      2     2
3      3     3
Sample Output:
Product of two matrix :
14      14      14
14      14      14
14      14      14
*/
int matrix_mul(int **, int, int, int **, int, int, int **, int, int);
int main()
{
    int **mat_1, **mat_2, **result;
	int row1, col1, row2, col2, row3, col3;
    //printf("Enter the no of rows : ");   //take rows from user
	scanf("%d", &row1);
   // printf("Enter the no of columns : ");   //take col from user
	scanf("%d", &col1);
	
	mat_1=malloc(row1 * sizeof(int *));  	//rows of matrix 1 using malloc function
	for(int i=0; i<row1; i++)               //columns of matrix 1 using mallotion
	{
	    mat_1[i]=malloc(col1 * sizeof(int));
	}
    //printf("Enter values for %d x %d matrix : \n",row1,col1);
    for(int i=0; i<row1; i++)   //reading the values for matrix 1 from user
	{
	    for(int j=0; j<col1; j++)
	    {
	        scanf("%d", &mat_1[i][j]);
	    }
	}
	
   // printf("Enter the no of rows : ");
	scanf("%d", &row2);    //take  rows from user
    //printf("Enter the no of columns : ");
	scanf("%d", &col2);
	
	mat_2=malloc(row2 * sizeof(int *));    	//row of matrix 2 using malloc function 
	for(int i=0; i<row2; i++)               //columns of matrix 2 using malloc function 
	{
	    mat_2[i]=malloc(col2 * sizeof(int));
	}
    //printf("Enter values for %d x %d matrix : \n",row2,col2);
    
    for(int i=0; i<row2; i++)      //reading the values for matrix 2 from user
	{
	    for(int j=0; j<col2; j++)
	    {
	        
	        scanf("%d", &mat_2[i][j]);
	    }
	}
	
    row3=row1;
	col3=col2;
	
	result=malloc(row3 * sizeof(int *));
	for(int i=0; i<row3; i++)
	{
	    result[i]=malloc(col3 * sizeof(int));
	}
	if(col1 == row2)
	{
	    matrix_mul(mat_1, row1, col1, mat_2, row2, col2, result, row3, col3);
	    
	    printf("Product of two matrix : \n");    	    //printing product of two matrix
	    for(int i=0; i<row3; i++)
	    {
	        for(int j=0; j<col3; j++)
	        {
	            printf("%d ", result[i][j]);
	        }
	        printf("\n");
	    }
	}
	else
	{
	    printf("Matrix multiplication is not possible\n");
	}
}

int matrix_mul(int **mat_1, int row1, int col1, int **mat_2, int row2, int col2, int **result, int row3, int col3)
{
    int sum=0;
    for(int i=0; i<row1; i++)
    {
        for(int j=0; j<col2; j++)
        {
            for(int k=0; k<col1; k++)
            {
                sum = sum + mat_1[i][k] * mat_2[k][j];   //product of two matrix
                result[i][j] = sum;
            }
            sum=0;  
        }
    }
}