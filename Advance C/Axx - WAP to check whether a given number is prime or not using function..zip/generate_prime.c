#include <stdio.h>
/*
Name: Sachin Belavi
Date: 14/09/2023
Title:WAP to check whether a given number is prime or not using function.
Sample Input:Enter a number : 2
Sample Output:2 is prime number
*/

int is_prime(int);
int main()
{
    int num;
    int ret;
    
    //printf("Enter the number: ");  //take number from user
    scanf("%d",&num);
    
    ret = is_prime(num);
    
    if(num > 0)     //condition to check number is greater than 0 or positive only
    {
        if(ret == 1)
        {
            printf("%d is a prime number\n",num);    //if ret == 1 the print prime number
        }
        else
        {
            printf("%d is not a prime number\n",num);   //if ret == 0 the print prime number
        }
    }
    else
    {
        printf("Invalid input\n");    
    }

}
int is_prime(int num)
{
    int k = 0;
        for(int i = 1; i <= num; i++)
        {
            if((num % i) == 0)        //Write logic to check the given number is prime or not
            {
                k = k + 1;
            }
        }
        if(k > 2)
        {
            return 0;
        }
        else
        {
            return 1;
        }
}