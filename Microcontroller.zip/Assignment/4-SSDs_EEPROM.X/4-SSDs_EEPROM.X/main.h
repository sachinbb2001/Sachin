#ifndef MAIN_H
#define MAIN_H

#define MAX_SSD_CNT		4
#define MAX_COUNT		9

#define COUNT_ADDR		0x00

#endif