#ifndef MAIN_H
#define MAIN_H

#define LED1				RB0

#define ON				1
#define OFF				0

#endif