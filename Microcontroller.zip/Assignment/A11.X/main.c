#include <xc.h>
#include "main.h"
#include "ssd_display.h"
#include "digital_keypad.h"

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
void init_config(void)
{
    init_digital_keypad();
	init_ssd_control();
}

void main(void)
{
	init_config();
    unsigned char key;
    unsigned int count = 0,delay=0;
	while(1)
	{
        key = read_digital_keypad(LEVEL);
        ssd[3] = digit[count%10];
        ssd[2] = digit[(count/10)%10];
        ssd[1] = digit[(count/100)%10];
        ssd[0] = digit[(count/1000)%10];
        display(ssd);
        if (key == SWITCH1)
        {
            delay++;
        }
        else if(delay > 150)
        {  
            count=0;
            delay = 0;
        }
        else if(delay > 0 && delay < 150)
        {
            delay = 0;
            if(count<9999)
                count++;
            else
                count=0;
        }
        else
        {
            delay = 0 ;
        }
    }
}