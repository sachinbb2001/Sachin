#ifndef MAIN_H
#define MAIN_H

#define LED1					PORTBbits.RB0

#endif