#include <xc.h>
#include "main.h"
#include "external_interrupt.h"
#include "isr.h"


 
unsigned int key_detected;

static void init_config(void)
{
        PEIE= 1;
	ADCON1 = 0x0F;

	TRISB6 = 0;
	TRISB0 = 1;

	init_external_interrupt();

	GIE = 1;


}

void main(void)
{
	unsigned short wait1;//key_detected;
	unsigned long int wait2;
	unsigned short once = 1;

	init_config();

	while (1)
	{
		
		if (key_detected)
		{
			key_detected = 0;
			RB6 = !RB6 ;
		}
;
	}
}







