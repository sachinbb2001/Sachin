#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"

void init_config(void)
{
	init_matrix_keypad();
	init_clcd();	
}

void main(void)
{
	init_config();
    unsigned char backup_key;
    static unsigned int i=0,flag=0,flag1=0;
    unsigned int j=0;
    char org_pass[8]={1,1,1,0,1,1,1,1};
    char temp_pass[8];
	while(1)
	{	
        clcd_print("Enter Password", LINE1(0));
        backup_key = read_switches(STATE_CHANGE);
        if(backup_key != ALL_RELEASED && i<8)
        {
            temp_pass[i] = backup_key;
            clcd_putch('*', LINE2(i));   
            if(org_pass[i] == temp_pass[i])
            {
                flag++;
            }
            i++;
        }  
        else if(i==8 && flag == i)
        {
            CLEAR_DISP_SCREEN;
            clcd_print("SACHIN", LINE1(0));
            while(1);
        }
        else if(i==8 && flag!=i)
        {
            flag1++;
            int n = flag1;
            switch(n)
            {   
                case 1:
                {
                    CLEAR_DISP_SCREEN;
                    clcd_print("Attempt1", LINE1(0));
                    clcd_print("Attempt left 4", LINE2(0));
                    for(int j=5000;j--;)
                        for(int i = 100; i--;);
                    CLEAR_DISP_SCREEN;
                    i = flag = 0;
                    break;
                }
                case 2:
                {
                    CLEAR_DISP_SCREEN;
                    clcd_print("Attempt 2", LINE1(0));
                    clcd_print("Attempt left 3", LINE2(0));
                    for(int j=5000;j--;)
                        for(int i = 100; i--;);
                    CLEAR_DISP_SCREEN;
                    i = flag = 0;
                    break;
                }
                case 3:
                {
                    CLEAR_DISP_SCREEN;
                    clcd_print("Attempt 3", LINE1(0));
                    clcd_print("Attempt left 2", LINE2(0));
                    for(int j=5000;j--;)
                        for(int i = 100; i--;);
                    CLEAR_DISP_SCREEN;
                    i = flag = 0;
                    break;
                }
                case 4:
                {
                    CLEAR_DISP_SCREEN;
                    clcd_print("Attempt 4", LINE1(0));
                    clcd_print("Attempt left 1", LINE2(0));
                    for(int j=5000;j--;)
                        for(int i = 100; i--;);
                    CLEAR_DISP_SCREEN;
                    i = flag = 0;
                    break;;
                }
                case 5:
                {
                    CLEAR_DISP_SCREEN;
                    clcd_print("You Are Blocked", LINE1(0));
                    clcd_print("Reset The Board", LINE2(0));
                    break;
                }   
                default:
                    break;
            }
        }
    }  
}
