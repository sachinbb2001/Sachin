#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
unsigned long wait = 0;
int i;
int flag = 0;
void glow_on_press(unsigned char key) {
    
    if (key == SWITCH1) 
    {
        PORTB = 0x00;
        flag = 1;
    } 
    else if (key == SWITCH2) 
    {
        PORTB = 0x00;
        flag = 2;
    } 
    else if (key == SWITCH3) {
        PORTB = 0xAA;
        flag = 3;
    } else if (key == SWITCH4) {
        PORTB = 0xF0;
        flag = 4;
    }

    if (flag == 1) 
    {
        if (wait++ == 50000) 
        {
            if (i < 8) 
            {
                PORTB = PORTB | (1 << i);
                i++;
                wait = 0;
            } 
            else if (i < 16) 
            {
                PORTB = PORTB & ~(1 << (i - 8));
                i++;
                wait = 0;
            } 
            else if (i <= 24) 
            {
                PORTB = PORTB | (1 << (24 - i));
                i++;
                wait = 0;
            }
            else if (i <= 32) {
                PORTB = PORTB & ~(1 << (32 - i));
                i++;
                wait = 0;
            }
            else 
            {
                wait = 0;
                i = 0;
            }
        }
    }
    else if (flag == 2) {
        if (wait++ == 50000) {
            if (i < 8) {
                PORTB = PORTB | (1 << i);
                i++;
                wait = 0;
            }
            else if (i < 16) {
                PORTB = PORTB & ~(1 << (i - 8));
                i++;
                wait = 0;
            }
        }
    }
    else if (flag == 3) {
        if (wait++ == 50000) {
            PORTB = ~PORTB;
            wait = 0;
        }
    }
    else if (flag == 4) {
        if (wait++ == 50000) {
            PORTB = ~PORTB;
            wait = 0;
        }
    }
}

static void init_config(void) {
    ADCON1 = 0x0F;
    TRISB = 0x00;
    PORTB = 0x00;

    init_digital_keypad();
}

void main(void) 
{
    unsigned char key,backup_key = 0x0f;
    init_config();
    while (1)
    {
        key = read_digital_keypad(STATE_CHANGE);
        if(key != ALL_RELEASED)
        {
            i = 0;
            backup_key = key;
        }
        glow_on_press(backup_key);
        backup_key = 0x0f;

    }
    return;
}
