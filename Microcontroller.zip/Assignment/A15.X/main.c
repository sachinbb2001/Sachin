#include <xc.h>
#include "main.h"
#include "ssd_display.h"

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE,BLANK,BLANK};
void init_config(void)
{
	init_ssd_control();
}

void main(void)
{
	init_config();
	unsigned int i=0,j=1,k=2,l=3;
    unsigned int wait=0;
	while(1)
	{
       
        if(wait++ == 150)
        {
            ssd[0] = digit[i++];
            ssd[1] = digit[j++];
            ssd[2] = digit[k++];
            ssd[3] = digit[l++];
            wait=0; 
            if(i==12)
            {
                i=0;
            }
            else if(j==12)
            {
                j=0;
            }
            else if(k==12)
            {
                k=0;
            }
            else if(l==12)
            {
                l=0;
            }
           
        }
        display(ssd);
    }     
        
	
}