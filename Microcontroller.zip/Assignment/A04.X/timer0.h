#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);
void init_timer1(void);
void init_timer2(void);


#endif