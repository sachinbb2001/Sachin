#include <xc.h>
#include "timer0.h"

void init_timer0(void)
{
	/*
	 * Setting instruction cycle clock (Fosc / 4) as the source of
	 * timer0
	 */

/*Setting 8 bit timer register*/
	T08BIT = 1;

/* Selecting internal clock source */
	T0CS = 0;

/* Enabling timer0*/
	TMR0ON = 1;

/* disabling prescaler*/
	PSA = 1;

	TMR0 = 6;

	/* Clearing timer0 overflow interrupt flag bit */
	TMR0IF = 0;

	/* Enabling timer0 overflow interrupt */
	TMR0IE = 1;
}
void init_timer1(void)
{
	

/* Selecting internal clock source */
	TMR1CS = 0;

/* Enabling timer1*/
	TMR1ON = 1;

	TMR1 = 3036;

	/* Clearing timer1 overflow interrupt flag bit */
	TMR1IF = 0;

	/* Enabling timer1 overflow interrupt */
	TMR1IE = 1;
}
void init_timer2(void)
{
	//T2OUTPS3:T2OUTPS0: Timer2 Output Postscale Select bits
	//Select 1:1 post scalar value
//	T2OUTPS3 = 0;
//	T2OUTPS2 = 0;
//	T2OUTPS1 = 0;
//	T2OUTPS0 = 0;

	//TMR2ON: Timer2 On bit
	//Switch on the timer2
	TMR2ON = 1;

	//T2CKPS1:T2CKPS0: Timer2 Clock Prescale Select bits
//	//Select the prescalar value as 1:16(Max)
//	T2CKPS1 = 1;
//	T2CKPS0 = 0; //Don't care

	//Value is calculated for the following data
	//XTAL freq		20MHz
	//PWM freq		2.5KHz
	//Duty Cycle	50%
	//Formula: (Fosc / (Fpwm * 4 * N)) - 1, where N is the prescalar value
	PR2 = 249;

	//Clear the timer2
	TMR2 = 6;

}