#include <xc.h>
#include "main.h"

void __interrupt() isr(void)
{
	static unsigned int count,count1;
     
	if (TMR0IF && TMR2IF)
	{
		TMR0 = TMR0 + 8;
        TMR2 = TMR2 + 8;
		if (count++ == 20000)
		{
			count = 0;
			LED1 = !LED1;
            LED3 = !LED3;
		}
		TMR0IF = 0;
        TMR2IF = 0;
	}
    if(TMR1IF)
    {
        TMR1 = TMR1 + 3038;
        if(count1++ == 80)
        {
            count1 = 0;
            LED2 = !LED2;
        }
        TMR1IF = 0;
    }
}