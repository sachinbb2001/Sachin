#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
#include "timer0.h"

#define PERIOD			100

void software_pwm(void)
{
	unsigned char key;
	static unsigned short wait = 0;
    static unsigned char prog_cycle;
	static unsigned char duty_change = 50;

	key = read_digital_keypad(STATE_CHANGE);

	if (!wait--)
	{
		wait = 1000;

		if (key == SWITCH1)
		{
			duty_change = 100;	
		}
	}
    if (prog_cycle < duty_change)
	{
	//	LED1 = ON;
	    RB0 = ON;
	}
	else
	{
		RB0 = OFF;
	}

	if (prog_cycle++ == PERIOD)
	{
		prog_cycle = 0;
	}
    if(TMR0IE = 0)
    {
       duty_change = 10;
    }
}

static void init_config(void)
{
	ADCON1 = 0x0F;

	RB0 = OFF;
	TRISB = 0;

	init_digital_keypad();
}

void main(void)
{
	init_config();

	while (1)
	{
		software_pwm();
	}
}
