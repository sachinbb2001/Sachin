#ifndef INIT_CCP_CONFIG_H
#define INIT_CCP_CONFIG_H

void init_CCP_config(void);

#endif