#!/bin/bash
<<DOC
Name: Sachin Belavi
Date:03/08/2023
Description: Count the number of users with user IDs between given range.
Sample Input: ./user_ids.sh 0 100
Sample Output:Total count of user ID between 0 to 100 is : 3
DOC

array=($(cut -d ":" -f3 /etc/passwd))                                #Store userId in Array
    count=0                                                              #Initialize count
    if [ $# -eq 0 ]                                                      #Command line argument is passed
    then
        for i in ${array[@]}                                             #For loop to get each userid
        do
            if [ $i -gt 500 -a $i -lt 10000 ]                              #By defualt if no cla passed it should check how many userid are there
            then
                count=$(($count+1))                                          #increament the count
            fi
        done
        echo "Total count of user ID between 500 to 10000 is:$count"     #Print the count
    elif [ $# -eq 2 ]                                                    #Check the if cla passed are equal 2
    then
        if [ $1 -lt $2 ]                                                     #condition to check first cla greater than Second
        then
            for i in ${array[@]}
            do
                if [ $i -gt $1 -a $i -lt $2 ]                                    #Check the number of id in between given range
                then
                    count=$(($count+1))                                          #get the number how many present in between given range
                fi
            done
            echo "Total count of user ID between $1 to $2 is:$count"         #Print the count
        else
            echo "Error:Invalid range .Please enter the valid range through CL." #if first argument greater than second .print error message
        fi
    else
        echo "Error:Please pass 2 arguments throgh CL."         #if command line arguments are not equal to 0 and 2.print the error message
        echo "Usage:./user_ids.sh 100 200"
    fi